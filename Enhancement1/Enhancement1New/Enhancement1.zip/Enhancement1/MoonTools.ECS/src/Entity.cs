﻿namespace MoonTools.ECS;

public readonly record struct Entity(uint ID);
