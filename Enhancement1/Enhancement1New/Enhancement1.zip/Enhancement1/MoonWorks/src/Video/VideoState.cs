namespace MoonWorks.Video
{
	public enum VideoState
	{
		Playing,
		Paused,
		Stopped
	}
}
