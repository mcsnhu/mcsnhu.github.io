namespace MoonWorks;

public readonly record struct AppInfo(string OrganizationName, string ApplicationName);
