namespace MoonWorks.Audio
{
	public enum FilterType
	{
		None,
		LowPass,
		BandPass,
		HighPass
	}
}
