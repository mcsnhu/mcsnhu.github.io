﻿namespace MoonWorks.Audio
{
	public enum SoundState
	{
		Playing,
		Paused,
		Stopped
	}
}
