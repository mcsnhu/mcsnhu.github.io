﻿namespace MoonWorks
{
	public enum ScreenMode
	{
		Fullscreen,
		Windowed
	}
}
