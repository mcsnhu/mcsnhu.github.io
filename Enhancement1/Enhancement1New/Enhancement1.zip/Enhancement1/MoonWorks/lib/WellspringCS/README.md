This is WellspringCS, a C# interop library for the [Wellspring](https://gitea.moonside.games/MoonsideGames/Wellspring) font rendering system.

License
-------
Wellspring and WellspringCS are released under the zlib license. See LICENSE for details.

About Wellspring
----------------
For more information about Wellspring, take a look at the Wellspring repository.

About WellspringCS
------------------
This interop library was designed for the [MoonWorks](https://gitea.moonside.games/MoonsideGames/MoonWorks) game framework. However, it can be integrated into any C# application.
